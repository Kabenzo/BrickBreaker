 _________                           __________        __                   __      __            .__       .___
 /   _____/__ ________   ___________  \______   \ _____/  |________  ____   /  \    /  \___________|  |    __| _/
 \_____  \|  |  \____ \_/ __ \_  __ \  |       _// __ \   __\_  __ \/  _ \  \   \/\/   /  _ \_  __ \  |   / __ | 
 /        \  |  /  |_> >  ___/|  | \/  |    |   \  ___/|  |  |  | \(  <_> )  \        (  <_> )  | \/  |__/ /_/ | 
/_______  /____/|   __/ \___  >__|     |____|_  /\___  >__|  |__|   \____/    \__/\  / \____/|__|  |____/\____ | 
        \/      |__|        \/                \/     \/                            \/                         \/ 
		
		

===============================================================================================
File : Super Retro World Desert Pack
Author : The low-res arist (Twitter @Pixelart_asset)
Version :
		0.1		31/01/21		Creation
		0.2		19/02/21		Improving the moutain tiles
		...		../../..		...

===============================================================================================

Hello and thank you for purchasing this pakage :) I hope it will be useful for you !

===============================================================================================
This package contains :

+ Super_Retro_World.zip
+	README.txt..................This file :)
+ 	atlas_16x.png...............The complete ressource in one file (16x pix size)
+ 	atlas_32x.png...............The complete ressource in one file (32x pix size)
+ 	atlas_48x.png...............The complete ressource in one file (48x pix size)
+	rpgmaker/...................Folder containing the atlas arranged in tileset for RPG MAKER VX, MV, MZ

===============================================================================================
Contact :

Project page : https://the-low-res-artist.itch.io/
Twitter @Pixelart_asset

